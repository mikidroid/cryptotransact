<footer>
    <div class="container text-center footer-container" style="max-width: 700px;">
      <h1>{{env('APP_NAME')}}</h1>
      <p>Invest with us and earn up to 10% of your first investment 100% guaranteed and amazingly great offer plus Decentralized Consulting Platform for Advisors, Crypto-Experts and Investors.</p>
      <ul>
        <li><a href="https://cointelegraph.com/bitcoin-for-beginners/what-are-cryptocurrencies" target="_blank">What is bitcoin?</a></li>
        <li><a href="https://www.investopedia.com/tech/how-to-buy-bitcoin/" target="_blank">How to buy bitcoin</a></li>
      </ul>
    </div>
    <div class="bg-dark p-3">
      <div class="container">
        <p class="m-0 text-center">Copyright © 2022 {{env('APP_NAME')}}, All Rights Reserved</p>
      </div>
    </div>
</footer>
