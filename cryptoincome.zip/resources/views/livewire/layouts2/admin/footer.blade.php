<footer class="foot" style="background-color: #eae8e9">
    <div class="container-fluid">
        <div class="copyright" align="center">
            Copyright &#169; <a href="/">{{env('APP_NAME')}}</a> 2022. All Rights Reserved.
        </div>
    </div>
</footer>
