<div class="jumbotron jumbotron-fluid gradient-custom4">
  <div class="container text-whit">
    <h2 class="display-4">Call Us Now!</h2>
    <p class="lead">Do you want to reach us? Contact us now and get more info.</p>
    <div class="d-flex justify-content-center align-items-center">
    <i class="fas fa-plug mr-1"></i>
     <span class="text-mutted">At Your Service </span>
     <a class="btn w-50 btn-primary btn-rounded p-2 ml-auto" href="tel:+2347018234978">Contact</a>
    </div>
  </div>
</div>