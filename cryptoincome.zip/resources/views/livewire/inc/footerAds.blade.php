

<!-- Ad2 Jumbotron -->

<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h2 class="display-4">Coaching on WhatsApp!</h2>
    <p class="lead">Do you want to grow your brand? find out the secrets to unlocking your business goals.</p>
    <div class="d-flex justify-content-center align-items-center">
    <i class="fas fa-plug mr-1"></i>
     <span class="text-mutted">A click away</span>
     <a class="btn w-50 btn-primary btn-rounded p-2 ml-auto" href="https://wa.me/message/KWLUKGP5L7EKG1">Visit</a>
    </div>
  </div>
</div>
  <!-- end advert2 -->
