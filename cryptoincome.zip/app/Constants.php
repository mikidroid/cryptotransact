<?php
namespace App;
  class Constants{
  	const S="/storage/app/public/";
  }
?>