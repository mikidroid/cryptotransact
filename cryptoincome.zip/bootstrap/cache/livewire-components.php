<?php return array (
  'auth-controller' => 'App\\Http\\Livewire\\AuthController',
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'inc.announcement' => 'App\\Http\\Livewire\\Inc\\Announcement',
  'inc.send-mail' => 'App\\Http\\Livewire\\Inc\\SendMail',
);