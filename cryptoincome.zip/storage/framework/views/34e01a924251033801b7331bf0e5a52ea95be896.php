 <div class="card bg-dark text-white">
  <div class="card-body">
 <h5 class="card-title" id="qualifications"><b style=""><i class="mr-2 fa fa-folder-open" aria-hidden="true"></i>Qualifications </b></h5>
 <hr/>
            <?php echo $qualifications; ?>

   </div>
   </div>
   <?php /**PATH C:\android\cryptoincome\resources\views/pages/inc/qualifications.blade.php ENDPATH**/ ?>