
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mt-4 mb-4">
     <div class="card-body">
<h4 class="card-title mb-3">Register</h4>
<hr/>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        
        <?php if(session('status')): ?>
            <div class="mb-4 alert alert-primary">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>

            <div>
                <label for="name">Name:</label>
                <input id="name" class="form-control mt-1" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            </div>
            
           <div class="mt-4">
                <label for="user_id" >User Id</label>
                <input id="user_id" class="form-control mt-1" type="text" name="user_id" :value="old('user_id')" required />
            </div>

            <div class="mt-4">
                <label for="email" >Email</label>
                <input id="email" class="form-control mt-1" type="email" name="email" :value="old('email')" required />
            </div>

            <div class="mt-4">
                <label for="password" >Password:</label>
                <input id="password" class="form-control mt-1" type="password" name="password" required autocomplete="new-password" />
            </div>

            <div class="mt-4">
                <label for="password_confirmation">Confirm Password</label>
                <input id="password_confirmation" class="form-control mt-1" type="password" name="password_confirmation" required autocomplete="new-password" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <a class="text-decoration-none" href="<?php echo e(route('login')); ?>">
                    <?php echo e(__('Already registered?')); ?>

                </a>

                <button class="alert-info ml-4">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>
        </form>
        </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\android\cryptoincome\resources\views/auth/register.blade.php ENDPATH**/ ?>