
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="no-js" lang="en-US">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link href="favicon.png" rel="icon" type="image/x-icon" />
<!-- Add icon library -->
<link rel="stylesheet" href="use.fontawesome.com/releases/v5.7.1/css/all.html" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
 <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->


<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- jQuery library -->
<script src="js/jquery.min.js"></script>
<!-- Popper JS -->
<script src="js/popper.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>

<!-- Main framwork compiled JavaScript -->
<script src="js/app.js"></script>

<link href="css/main.css" rel="stylesheet"/>
<link href="404.html" rel="stylesheet" />
<link href="css/animate.css" rel="stylesheet" />

<title><?php echo e(env('APP_NAME')); ?></title>
<link rel="manifest" href="js/manifest.json">
<meta name="theme-color" content="#2970fa">
<meta name="msapplication-navbutton-color" content="#2970fa">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-status-bar-style" content="#2970fa">


<meta name="theme-color" content="#2970fa">
<meta name="msapplication-navbutton-color" content="#2970fa">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-status-bar-style" content="#2970fa">

<link href="favicon.png" rel="icon" type="image/x-icon" />
<link rel="icon" sizes="192x192" href="404.html">

<meta name="keywords" content="<?php echo e(env('APP_NAME')); ?>, Options, Binary" />


<link rel="apple-touch-icon-precomposed" href="images/icon/apple-touch-icon.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="404.html" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="404.html" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/icon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/icon/apple-touch-icon-144x144.png" />


<meta property="og:site_name" content="<?php echo e(env('APP_NAME')); ?>">
<meta property="og:title" content="Binary Trading With <?php echo e(env('APP_NAME')); ?>" />
<meta name="description" content="Binary Trading With <?php echo e(env('APP_NAME')); ?>, is totally different from its competitors trying to achieve something special starting with the...">
<meta property="og:description" content="Binary Trading With <?php echo e(env('APP_NAME')); ?>, is totally different from its competitors trying to achieve something special starting with the...">
<meta property="og:type" content="website" />


<link href="css/select2.min.css" rel="stylesheet" />
</head>
<body>

<?php echo $__env->make('livewire.navBar.navGuest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<style>
.slick-dots{bottom: -10px !important;}
.slick-dotted.slick-slider{ margin-bottom: 0px;}
</style>

<div>
<?php echo $__env->yieldContent('content'); ?>
</div>

<script src="slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script src="slick/slick-animation.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
	// Init slick slider + animation
	$(document).ready(function(){

  $(".testimonials").slick({
    autoplay:true,
    autoplaySpeed:10000,
    speed:600,
    slidesToShow:1,
    slidesToScroll:1,
    pauseOnHover:false,
    dots:false,
	arrows: false,
	adaptiveHeight: true
  });

})
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f6dc1ca4704467e89f238a5/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<div class="modal" id="myCookie">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title"><i class="fas fa-shield-alt mr-2 text-danger" style="font-size: 32px;"></i>This website uses cookies</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <p>By clicking “Continue”, you agree to the default cookie settings on our website.</p>
        <button type="button" class="cookieBtn btn btn-success border-0 mb-3">Continue</button>
        <p><?php echo e(env('APP_NAME')); ?> uses cookies to ensure that we provide you with the best experience while visiting our website. Some of the cookies are needed to provide essential features, such as login sessions, and cannot be disabled. Other cookies help us improve our website’s performance and your experience through personalising content, providing social media features and analysing our traffic. Such cookies may also include third-party cookies, which might track your use of our website. You may change your cookie settings at any time.</p>
      </div>
      <div class="modal-footer d-flex">
        <p class="m-0">Read more, or change your <a href="cookies.html">cookie settings</a>.</p>
        <img src="images/water-mark.png" style="width: 40px; height: 40px" class="ml-auto"/>
      </div>

    </div>
  </div>
</div>

<script>
    $(document).ready(function(){
        if (getCookie("cookiePopup") == null){
            $("#myCookie").modal();
        }
        $(".cookieBtn").click(function () {
          $("#myCookie").modal("hide");
            setCookie("cookiePopup", 0);
        });
    });

    function setCookie(c_name, value, exdays) {
        var exdate = new Date();
        exdate.setDate(exdate.getDate() + exdays);
        var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
        document.cookie = c_name + "=" + c_value;
    }
    function getCookie(c_name) {
        var i, x, y, ARRcookies = document.cookie.split(";");
        for (i = 0; i < ARRcookies.length; i++) {
            x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
            y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
            x = x.replace(/^\s+|\s+$/g, "");
            if (x == c_name) {
                return unescape(y);
            }
        }
    }
    </script>
<footer>
    <div class="container text-center footer-container" style="max-width: 700px;">
      <h1><?php echo e(env('APP_NAME')); ?></h1>
      <p>Invest with us and earn up to 10% of your first investment 100% guaranteed and amazingly great offer plus Decentralized Consulting Platform for Advisors, Crypto-Experts and Investors.</p>
      <ul>
        <li><a href="https://cointelegraph.com/bitcoin-for-beginners/what-are-cryptocurrencies" target="_blank">What is bitcoin?</a></li>
        <li><a href="https://www.investopedia.com/tech/how-to-buy-bitcoin/" target="_blank">How to buy bitcoin</a></li>
      </ul>
    </div>
    <div class="bg-dark p-3">
      <div class="container">
        <p class="m-0 text-center">Copyright © 2022 <?php echo e(env('APP_NAME')); ?>, All Rights Reserved</p>
      </div>
    </div>
</footer>

<script>
new WOW().init();
</script>
<script>
  (function(b,i,t,C,O,I,N) {
    window.addEventListener('load',function() {
      if(b.getElementById(C))return;
      I=b.createElement(i),N=b.getElementsByTagName(i)[0];
      I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
    },false)
  })(document,'script','https://widgets.bitcoin.com/widget.js','btcwdgt');
</script>

<div id="google_translate_element" style="display:none"></div>
<script type="text/javascript">

function readCookie(name) {
    var c = document.cookie.split('; '),
    cookies = {}, i, C;

    for (i = c.length - 1; i >= 0; i--) {
        C = c[i].split('=');
        cookies[C[0]] = C[1];
     }

     return cookies[name];
}
var lang = readCookie('googtrans').slice(-2);
$('#language option[value="'+lang+'"]').prop('selected', true);

function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: "en"}, 'google_translate_element');
}

function changeLanguageByButtonClick() {
  var language = document.getElementById("language").value;
  var selectField = document.querySelector("#google_translate_element select");
  for(var i=0; i < selectField.children.length; i++){
    var option = selectField.children[i];
    // find desired langauge and change the former language of the hidden selection-field
    if(option.value==language){
       selectField.selectedIndex = i;
       // trigger change event afterwards to make google-lib translate this side
       selectField.dispatchEvent(new Event('change'));
       break;
    }
  }
}

function changeLanguageByButtonClick2() {
  var language = document.getElementById("language2").value;
  var selectField = document.querySelector("#google_translate_element select");
  for(var i=0; i < selectField.children.length; i++){
    var option = selectField.children[i];
    // find desired langauge and change the former language of the hidden selection-field
    if(option.value==language){
       selectField.selectedIndex = i;
       // trigger change event afterwards to make google-lib translate this side
       selectField.dispatchEvent(new Event('change'));
       break;
    }
  }
}
</script>

<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

</body>

<!-- Mirrored from <?php echo e(env('APP_NAME')); ?>.com/home/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Feb 2022 11:13:30 GMT -->
</html>
<?php /**PATH C:\android\cryptoincome\resources\views/layouts/newlayer.blade.php ENDPATH**/ ?>