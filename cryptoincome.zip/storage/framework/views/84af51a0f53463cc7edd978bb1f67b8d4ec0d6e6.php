
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mt-4 mb-5">
        
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <?php if(session('status')): ?>
            <div class="mb-4 alert alert-primary">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

   <form method="POST" action="<?php echo e(route('login')); ?>">
   <?php echo csrf_field(); ?>
   <div class="card-body">
<h4 class="card-title mb-3">Login</h4>
<hr/>
    
   <label for="email">Email</label>
   <input id="email" class="form-control mb-3" type="email" name="email" :value="old('email')" required autofocus />
        
  <label for="password" >Password</label>
  <input id="password" class="form-control mb-3" type="password" name="password" required autocomplete="current-password" />
            
   <div class="form-group form-check">
   <input type="checkbox" class="form-check-input" id="remember_me" name="remember" />
  <label for="remember_me" class="form-check-label">Remember me</label></div>
                
  <div class="flex items-center justify-end mt-4">
  <?php if(Route::has('password.request')): ?>
  <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
  <?php echo e(__('Forgot your password?')); ?>

  </a>
  <?php endif; ?>

  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'ml-4 btn btn-primary-outline text-dark']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4 btn btn-primary-outline text-dark']); ?>
                    <?php echo e(__('Log in')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            </div>
        </form>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\android\cryptoincome\resources\views/auth/login.blade.php ENDPATH**/ ?>