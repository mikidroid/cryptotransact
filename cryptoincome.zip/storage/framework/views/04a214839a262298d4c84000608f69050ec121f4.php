<footer class="foot" style="background-color: #eae8e9">
    <div class="container-fluid">
        <div class="copyright" align="center">
            Copyright &#169; <a href="/"><?php echo e(env('APP_NAME')); ?></a> 2022. All Rights Reserved.
        </div>
    </div>
</footer>
<?php /**PATH C:\android\cryptoincome\resources\views/livewire/layouts2/admin/footer.blade.php ENDPATH**/ ?>