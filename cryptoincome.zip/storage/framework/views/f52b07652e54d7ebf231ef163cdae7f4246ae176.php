 <div class="d-flex row bg-light container-fluid" style="height:50px">
  <div class="ml-4 mt-3"> 
  <img class="mb-1 ml-1" style="object-fit:cover" src="/storage/core/Logo.png" width="15px" height="25px"><a class="text-decoration-none text-dark" href="/">
 <span class=" mt-3 ml-1 text-dark" style="font-weight:600;font-size:19px"> <?php echo e(env('APP_NAME')); ?></span> </a>
 </div>
 </div><?php /**PATH C:\android\cryptoincome\resources\views/inc/brand.blade.php ENDPATH**/ ?>