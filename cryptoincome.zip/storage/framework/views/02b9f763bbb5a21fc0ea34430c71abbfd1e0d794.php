<?php echo $__env->make('livewire.layouts2.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.admin.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="prnt"></div>

          <div class="row">
            <div class="col-md-4">
              <div class="card">

                <div class="card-header">
                  <div class="card-title"> Fund Transfer </div>
                </div>

                <div class="card-body pb-0">
                                        <div class="">
                        <form action="/user/activity" method="post" enctype="multipart/form-data">
                         <?php echo csrf_field(); ?>
                          <div class="form-group" align="left">
                            <input type="hidden" class="form-control" name="type" value="transfer">
                          </div>
                          <div class="input-group pad_top10" >
                            <div class="input-group-prepend" >
                              <span class="input-group-text "><i class="fa fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" name="receiver"  required placeholder="Username" >
                          </div>
                          <div class="input-group pad_top10">
                            <div class="input-group-prepend" >
                              <span class=" input-group-text ">$</span>
                            </div>
                            <input type="number" class="form-control" name="amount"  required placeholder="Enter amount you want to send" >
                          </div>

                          <div class="form-group" align="">
                            <br><br>
                              <button class="btn btn_blue">Send</button>
                              <br>
                          </div>
                        </form>
                        <br><br>
                    </div>
                </div>
              </div>
            </div>

            <div class="col-md-8">
              <div class="card">
                <div class="card-header">
                  <div class="card-title">Transfer History </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive"><table id="basic-datatables" class="display table table-striped table-hover" >
        <thead>
            <tr>
                <th>Sender</th>
                <th>Receiver</th>
                <th>Amount</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tra->sender); ?></td>
                <td><?php echo e($tra->receiver); ?></td>
                <td><?php echo e($tra->amount); ?></td>
                <td><?php echo e($tra->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </tbody>
    </table>
</div>
                       </div>
              </div>
            </div>

          </div>

          <div class="row">

          </div>

        </div>
      </div>

<?php echo $__env->make('livewire.layouts2.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.admin.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\android\cryptoincome\resources\views/livewire/admin/transfer.blade.php ENDPATH**/ ?>