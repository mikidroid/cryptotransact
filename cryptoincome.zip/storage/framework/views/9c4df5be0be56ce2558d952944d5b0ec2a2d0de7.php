<?php $__env->startSection('content'); ?>

<div class="bg-about">
	<div class="container">
		<h1>Contact Us</h1>
		<p>Feel free to drop us a message, What can we help you with?</p>
	</div>
</div>
<div class="container">
<div class="row">
	<div class="col-12 col-lg-8 p-4">
		<div class="alerter"></div>

	</div>
	<div class="col-12 col-lg-12 p-4">
			<ul class="contact_list shadow">
								<li>
					<i class="fas fa-map-marker-alt text-primary wow fadeIn"></i>
					<div>
						<h2>Company Address:</h2>
						<p class="m-0"> <?php echo e(env('ADMIN_ADDRESS')); ?></p>
					</div>
				</li>
								<li>
					<i class="fas fa-comment-dots text-primary wow fadeIn"></i>
					<div>
						<h2>Phone Number:</h2>
						<p class="m-0"><a href="#" target="_blank"><?php echo e(env('ADMIN_PHONE_NUMBER')); ?></a></p>
					</div>
				</li>
								<li>
					<i class="fa fa-envelope text-primary wow fadeIn"></i>
					<div>
						<h2>Company Email:</h2>
						<p class="m-0"><a href="mailto://<?php echo e(env('ADMIN_EMAIL')); ?>">info@ <?php echo e(env('APP_NAME')); ?> .com</a></p>
					</div>
				</li>
			</ul>
	</div>
 </div>


</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('homeFunctions'); ?>
<?php echo $__env->make('livewire.layouts2.footer.homeJsFunctions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\android\cryptoincome\resources\views/livewire/pages/contact.blade.php ENDPATH**/ ?>