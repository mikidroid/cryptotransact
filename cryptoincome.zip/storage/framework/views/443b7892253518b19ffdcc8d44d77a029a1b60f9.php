<?php echo $__env->make('livewire.layouts2.user.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.user.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="prnt"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-head-row">
                                        <div class="card-title">
                                            Referral link:
                                            <a href="/register/teepee" class="text-danger" id="reflnk" >
                                                <small><?php echo e($user->ref_link); ?></small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">My Downlines</div>
                                </div>
                                <div class="card-body pb-5">


                                            <div class="table-responsive mt-5">
                                                <table id="basic-datatables" class="display table table-striped table-hover" >
                                                    <thead>
                                                        <tr>
                                                            <!-- <th data-field="state" data-checkbox="true"></th> -->
                                                            <th>Name</th>
                                                            <th>Username</th>
                                                            <th>Level</th>
                                                            <th>Amount Earned</th>
                                                            <th>Investment</th>
                                                            <th>Date Registered</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                                <tr>
                                                                <td colspan="4">No data</td>
                                                                </tr>
                                                      </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <!-- <th data-field="state" data-checkbox="true"></th> -->
                                                            <th>Name</th>
                                                            <th>Username</th>
                                                             <th>Level</th>
                                                            <th>Amount Earned</th>
                                                            <th>Investment</th>
                                                            <th>Date Registered</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
            
                                                <br><br>
                                            </div>





                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


<?php echo $__env->make('livewire.layouts2.user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.user.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\android\cryptoincome\resources\views/livewire/user/downlines.blade.php ENDPATH**/ ?>