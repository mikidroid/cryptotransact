
<?php $__env->startSection('content'); ?>
<div class="row"  style="
    overflow:hidden;
    background:url('/storage/background-imaes/image2.jpg') no-repeat center/cover;   
    font-family:poppins;
    font-size:14px;
    color:#565656;" >
 
<!--header image -->
<?php echo $__env->make('pages.inc.headerImage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Product slide -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.product-slide', [])->html();
} elseif ($_instance->childHasBeenRendered('PCnWGcV')) {
    $componentId = $_instance->getRenderedChildComponentId('PCnWGcV');
    $componentTag = $_instance->getRenderedChildComponentTagName('PCnWGcV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PCnWGcV');
} else {
    $response = \Livewire\Livewire::mount('admin.product-slide', []);
    $html = $response->html();
    $_instance->logRenderedChild('PCnWGcV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<!-- Call to Action -->
<?php echo $__env->make('inc.callToAction1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--start container-->
<div class="container">
<?php echo $__env->make('pages.inc.ImgBack', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="row" style="margin:20px">
 
<!--col 1 -->
 <div class="col-sm-12 col-md-6 col-lg-6" style=";" >
<!--import core values -->
<?php echo $__env->make('pages.inc.coreValues', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--import bio /skills/ achievements -->
<?php echo $__env->make('pages.inc.bioSkillAchievements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!--End col 1 -->


<!--col 2 -->
 <div class="col-sm-10 col-md-6 col-lg-6" style=";" >

<!--import qualifications -->
<?php echo $__env->make('pages.inc.qualifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--import projects -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.project-slide', [])->html();
} elseif ($_instance->childHasBeenRendered('EuwTYJY')) {
    $componentId = $_instance->getRenderedChildComponentId('EuwTYJY');
    $componentTag = $_instance->getRenderedChildComponentTagName('EuwTYJY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EuwTYJY');
} else {
    $response = \Livewire\Livewire::mount('admin.project-slide', []);
    $html = $response->html();
    $_instance->logRenderedChild('EuwTYJY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<!-- End col 2 -->

</div>
<!-- End row 1 -->

  </div>
 <!-- end  container-->
  </div>
<!-- end row -->


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('articles.article-slide', [])->html();
} elseif ($_instance->childHasBeenRendered('jYv7HYG')) {
    $componentId = $_instance->getRenderedChildComponentId('jYv7HYG');
    $componentTag = $_instance->getRenderedChildComponentTagName('jYv7HYG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jYv7HYG');
} else {
    $response = \Livewire\Livewire::mount('articles.article-slide', []);
    $html = $response->html();
    $_instance->logRenderedChild('jYv7HYG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<!-- footer Advert -->
<?php echo $__env->make('inc.footerAds', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\android\cryptoincome\resources\views/pages/home.blade.php ENDPATH**/ ?>