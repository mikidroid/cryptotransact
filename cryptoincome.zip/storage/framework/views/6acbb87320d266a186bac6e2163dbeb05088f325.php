<div style="
position: absolut;
opacity:;
  left: px;
object-fit: ;
  top: px;
  z-index: ;
  width:;
  text-align:center;
  overflow:hidden;">
 
<img class="rounded-cirl"  style="
overflow:hidden"  width="100%" src="/storage/core/homePersonalPic.jpg">

</div><?php /**PATH C:\android\cryptoincome\resources\views/pages/inc/headerImage.blade.php ENDPATH**/ ?>