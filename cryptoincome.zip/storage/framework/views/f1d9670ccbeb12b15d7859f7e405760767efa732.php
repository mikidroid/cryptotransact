<img src="<?php echo e(asset('img/bg1.jpeg')); ?>" width="100%" height="" style="
      top:1150px;
      opacity:0.05;
      left:0px;
      padding:px;
      
      color:#efefef;
      
      z-index:-1;
      position:absolute;
      font-size:60px;
      font-family:poppins;
      font-weight:800;
        ">
<img src="<?php echo e(asset('img/bg3.jpeg')); ?>" width="100%" height="" style="
      top:400px;
      opacity:0.1;
      left:0px;
      padding:px;
      
      color:#efefef;
      
      z-index:-1;
      position:absolute;
      font-size:60px;
      font-family:poppins;
      font-weight:800;
        ">
<img src="<?php echo e(asset('img/bg2.jpeg')); ?>" width="100%" height="" style="
      top:650px;
      opacity:0.05;
      left:0px;
      padding:px;
      
      color:#efefef;
      
      z-index:-1;
      position:absolute;
      font-size:60px;
      font-family:poppins;
      font-weight:800;
        ">
        
<img src="<?php echo e(asset('img/bg5.jpeg')); ?>" width="100%" height="" style="
      top:900px;
      opacity:0.07;
      left:0px;
      padding:px;
      
      color:#efefef;
      
      z-index:-1;
      position:absolute;
      font-size:60px;
      font-family:poppins;
      font-weight:800;
        ">
        
<img src="<?php echo e(asset('img/bg3.jpeg')); ?>" width="100%" height="" style="
      top:1450px;
      opacity:0.2;
      left:0px;
      padding:px;
      
      color:#efefef;
      
      z-index:-1;
      position:absolute;
      font-size:60px;
      font-family:poppins;
      font-weight:800;
        "><?php /**PATH C:\android\cryptoincome\resources\views/pages/inc/ImgBack.blade.php ENDPATH**/ ?>