<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show">
    <h4 class='text-success'><b><?php echo e(Session::get('success')); ?></b></h4>
    <button type="button" class="close" data-dismiss="alert">&times;</button>
</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <h4 class='text-danger'><b><?php echo e(Session::get('error')); ?></b></h4>
    <button type="button" class="close" data-dismiss="alert">&times;</button>
</div>
<?php endif; ?>
<?php /**PATH C:\android\cryptoincome\resources\views/livewire/inc/flashMessages.blade.php ENDPATH**/ ?>