<?php echo $__env->make('livewire.layouts2.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.admin.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="prnt"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-head-row">

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">All Users</div>
                                </div>
                                <div class="card-body pb-5">


                                            <div class="table-responsive mt-5">
                                                <table id="basic-datatables" class="display table table-striped table-hover" >
                                                    <thead>
                                                        <tr>
                                                            <!-- <th data-field="state" data-checkbox="true"></th> -->

                                                            <th>Username</th>
                                                            <th>Email</th>
                                                            <th>Phone</th>
                                                            <th>Balance</th>
                                                            <th>Investments</th>
                                                            <th>Withdrawals</th>
                                                            <th>Date Registered</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <!-- <th data-field="state" data-checkbox="true"></th> -->
                                                                    <td><?php echo e($user->username); ?></td>
                                                                    <td><?php echo e($user->email); ?></td>
                                                                    <th><?php echo e($user->phone); ?></th>
                                                                    <td>$<?php echo e($user->balance); ?></td>
                                                                    <td><?php echo e($user->investments); ?></td>
                                                                    <td><?php echo e($user->withdrawals); ?></td>
                                                                    <td><?php echo e($user->created_at); ?></td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <!-- <th data-field="state" data-checkbox="true"></th> -->
                                                            <th>Username</th>
                                                            <th>Email</th>
                                                            <th>Phone</th>
                                                            <th>Balance</th>
                                                            <th>Investments</th>
                                                            <th>Withdrawals</th>
                                                            <th>Date Registered</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>

                                                <br><br>
                                            </div>





                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


<?php echo $__env->make('livewire.layouts2.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.layouts2.admin.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\android\cryptoincome\resources\views/livewire/admin/users.blade.php ENDPATH**/ ?>